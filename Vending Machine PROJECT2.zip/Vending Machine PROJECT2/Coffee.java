public class Coffee extends Beverage{
	
	@Override
	public void drink() {
		System.out.println("COFFEE DETAIL");
		System.out.println("Drink the Coffee");
		System.out.println("Name: Cappuccino");
		System.out.println("size: LARGE");
		System.out.println("Temperature: Hot/cool");
	}

}
