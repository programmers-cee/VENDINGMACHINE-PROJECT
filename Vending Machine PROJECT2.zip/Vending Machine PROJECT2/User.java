import java.util.Scanner;
public class User {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		char c;
		vendingMachine vm=new vendingMachine();
		do {
			Beverage b1=vm.pressButton();
			b1.drink();
			System.out.println("Press Y/y to continue...");
			c=sc.next().charAt(0);
		}while(c=='Y' || c=='y');
		System.out.println("=====Game Ends=====");
	}
}
