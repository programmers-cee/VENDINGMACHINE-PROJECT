public class Juice extends Beverage{
	
	@Override
	public void drink() {
		System.out.println("JUICE DETAIL");
		System.out.println("Drink the Juice");
		System.out.println("Name: Orange-Carrot");
		System.out.println("Size: Medium");
		System.out.println("Fresh: Yes");
	}

}
