public class Wine extends Beverage{
	
	@Override
	public void drink() {
		System.out.println("WINE DETAIL");
		System.out.println("COFFEE IN DETAIL");
		System.out.println("Name: Merlot");
		System.out.println("TYPE: RED");
		System.out.println("Alcohol Content: 13.5%");
		System.out.println("Region: Bordeaux, France");
		System.out.println("Aged: Yes");
	}

}
