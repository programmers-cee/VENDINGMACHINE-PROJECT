import java.util.Scanner;
public class vendingMachine {
	
	
	public Beverage pressButton() {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the press: " );
		int score=sc.nextInt();
		if(score<=400){
			System.out.println("You got drink..");
			Coffee c=new Coffee();
		return c;
		}
		else if(score<=800) {
			System.out.println("Press 1 for Coffee");
			System.out.println("Press 2 for Juice");
			int choice=sc.nextInt();
			if(choice==1) {
				System.out.println("You got Coffee..");
				Coffee c=new Coffee();
			return c;
			}else {
				System.out.println("You got the Juice");
				Juice j=new Juice();
			return j;
			}
		}
		else {
			System.out.println("Press 1 for Coffed");
			System.out.println("Press 2 for Juice");
			System.out.println("Press 3 for Wine");
			int choice=sc.nextInt();
			if(choice==1) {
				System.out.println("You got Drink..");
				Coffee c=new Coffee();
			return c;
			}else if(choice==2){
				System.out.println("You got the Drink");
				Juice j=new Juice();
			return j;
			}
			else {
				System.out.println("You got Drink..");
				Wine d=new Wine();
			return d;
			}
		}
	}

}
