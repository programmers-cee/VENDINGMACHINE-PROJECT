public class Beverage {
	
	public void drink() {
		System.out.println();
	}

}
